import { log, logger } from "./logger-LJ5xGY9g.js";
export { log, logger };
